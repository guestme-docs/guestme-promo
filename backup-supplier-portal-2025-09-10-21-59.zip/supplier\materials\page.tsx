export default function MaterialsPage() {
  return null; // временно отключено на этом этапе
}


