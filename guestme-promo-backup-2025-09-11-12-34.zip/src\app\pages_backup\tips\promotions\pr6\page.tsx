import TipsPromotionDetailClient from '../client';

export default function TipsPromotionPr6Page() {
  return <TipsPromotionDetailClient promotionId="pr6" />;
}
