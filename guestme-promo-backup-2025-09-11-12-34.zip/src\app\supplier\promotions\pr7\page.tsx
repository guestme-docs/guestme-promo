import PromotionDetailClient from '../components/PromotionDetailClient';

export default function PromotionPr7Page() {
  return <PromotionDetailClient params={Promise.resolve({ id: 'pr7' })} />;
}
