import TipsPromotionDetailClient from '../components/TipsPromotionDetailClient';

export default function TipsPromotionPr8Page() {
  return <TipsPromotionDetailClient promotionId="pr8" />;
}

