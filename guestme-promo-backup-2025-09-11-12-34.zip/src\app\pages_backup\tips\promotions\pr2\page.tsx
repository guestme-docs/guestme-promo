import TipsPromotionDetailClient from '../client';

export default function TipsPromotionPr2Page() {
  return <TipsPromotionDetailClient promotionId="pr2" />;
}
