import TipsPromotionDetailClient from '../components/TipsPromotionDetailClient';

export default function TipsPromotionPr6Page() {
  return <TipsPromotionDetailClient promotionId="pr6" />;
}

