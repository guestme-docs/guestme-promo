import TipsPromotionDetailClient from '../client';

export default function TipsPromotionPr3Page() {
  return <TipsPromotionDetailClient promotionId="pr3" />;
}
