import TipsPromotionDetailClient from '../components/TipsPromotionDetailClient';

export default function TipsPromotionPr7Page() {
  return <TipsPromotionDetailClient promotionId="pr7" />;
}

