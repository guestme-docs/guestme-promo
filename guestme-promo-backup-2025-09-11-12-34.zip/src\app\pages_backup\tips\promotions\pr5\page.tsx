import TipsPromotionDetailClient from '../client';

export default function TipsPromotionPr5Page() {
  return <TipsPromotionDetailClient promotionId="pr5" />;
}
