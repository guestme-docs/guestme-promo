import TipsPromotionDetailClient from '../components/TipsPromotionDetailClient';

export default function TipsPromotionPr1Page() {
  return <TipsPromotionDetailClient promotionId="pr1" />;
}

