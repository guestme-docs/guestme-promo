import TipsPromotionDetailClient from '../client';

export default function TipsPromotionPr8Page() {
  return <TipsPromotionDetailClient promotionId="pr8" />;
}
