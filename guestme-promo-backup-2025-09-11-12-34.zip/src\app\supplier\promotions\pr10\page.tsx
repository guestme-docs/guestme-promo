import PromotionDetailClient from '../components/PromotionDetailClient';

export default function PromotionPr10Page() {
  return <PromotionDetailClient params={Promise.resolve({ id: 'pr10' })} />;
}
