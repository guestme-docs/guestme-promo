import TipsPromotionDetailClient from '../components/TipsPromotionDetailClient';

export default function TipsPromotionPr5Page() {
  return <TipsPromotionDetailClient promotionId="pr5" />;
}

