import TipsPromotionDetailClient from '../client';

export default function TipsPromotionPr1Page() {
  return <TipsPromotionDetailClient promotionId="pr1" />;
}
