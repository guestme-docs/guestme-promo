import PromotionDetailClient from '../components/PromotionDetailClient';

export default function PromotionPr6Page() {
  return <PromotionDetailClient params={Promise.resolve({ id: 'pr6' })} />;
}
