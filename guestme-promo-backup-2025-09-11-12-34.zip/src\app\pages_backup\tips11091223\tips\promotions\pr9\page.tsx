import TipsPromotionDetailClient from '../components/TipsPromotionDetailClient';

export default function TipsPromotionPr9Page() {
  return <TipsPromotionDetailClient promotionId="pr9" />;
}

