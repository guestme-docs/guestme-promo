import TipsPromotionDetailClient from '../client';

export default function TipsPromotionPr7Page() {
  return <TipsPromotionDetailClient promotionId="pr7" />;
}
