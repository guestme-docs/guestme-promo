import TipsPromotionDetailClient from '../client';

export default function TipsPromotionPr10Page() {
  return <TipsPromotionDetailClient promotionId="pr10" />;
}
