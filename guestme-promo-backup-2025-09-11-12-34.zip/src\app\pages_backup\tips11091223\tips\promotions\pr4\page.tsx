import TipsPromotionDetailClient from '../components/TipsPromotionDetailClient';

export default function TipsPromotionPr4Page() {
  return <TipsPromotionDetailClient promotionId="pr4" />;
}

