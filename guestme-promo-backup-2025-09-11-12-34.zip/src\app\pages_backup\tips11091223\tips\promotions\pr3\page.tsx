import TipsPromotionDetailClient from '../components/TipsPromotionDetailClient';

export default function TipsPromotionPr3Page() {
  return <TipsPromotionDetailClient promotionId="pr3" />;
}

