import TipsPromotionDetailClient from '../client';

export default function TipsPromotionPr4Page() {
  return <TipsPromotionDetailClient promotionId="pr4" />;
}
