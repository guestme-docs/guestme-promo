import TipsPromotionDetailClient from '../components/TipsPromotionDetailClient';

export default function TipsPromotionPr2Page() {
  return <TipsPromotionDetailClient promotionId="pr2" />;
}

