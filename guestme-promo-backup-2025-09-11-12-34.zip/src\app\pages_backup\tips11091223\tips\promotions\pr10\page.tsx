import TipsPromotionDetailClient from '../components/TipsPromotionDetailClient';

export default function TipsPromotionPr10Page() {
  return <TipsPromotionDetailClient promotionId="pr10" />;
}

